import setuptools

setuptools.setup(
    name="pysparkprocessor-expecc",
    version="0.0.1",
    author="expecc",
    author_email="expecc@expecc.com",
    description="Common package for pyspark processing",
    packages=setuptools.find_packages(),
    include_package_data=True
)
